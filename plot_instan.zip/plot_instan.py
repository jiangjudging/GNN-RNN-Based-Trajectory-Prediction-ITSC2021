from matplotlib import pyplot as plt
from moviepy.editor import VideoClip
from moviepy.video.io.bindings import mplfig_to_npimage


def plot_glb_frm(hists, fut_pred, fut_gt, save_path=None, xlim=None, ylim=None):
    """
    画一帧的图

    Parameters
    ----------
    hists : np.array(n*30*2)
        n表示车辆的数目，其中第0个必须是目标车辆的数据，后面的是周围车辆的轨迹
        30表示过去30帧
        2表示x,y坐标
    fut_pred : 50*2
        目标车辆的预测未来轨迹
        50表示未来50帧
        2表示x,y坐标
    fut_gt : 50*2  
        目标车辆的实际未来轨迹
        50表示未来50帧
        2表示x,y坐标
    save_path : string, optional
        照片保存路径, by default None
    xlim : tuple, optional
        x坐标轴的范围, by default None
    ylim : tuple, optional
        y坐标轴的范围, by default None
    """
    fig, ax = plt.subplots(dpi=300)
    # fig.set_tight_layout(True)

    # ax.set_aspect(3)
    if xlim is not None:
        plt.xlim(*xlim)
    if ylim is not None:
        plt.ylim(*ylim)

    for i, veh_hist in enumerate(hists):
        if i == 0:
            ax.plot(veh_hist[:, 0], veh_hist[:, 1], 'b', label='target_hist')
            ax.plot(veh_hist[:, 0], veh_hist[:, 1], '.b')
            ax.plot(veh_hist[-1, 0], veh_hist[-1, 1], 'or')
        else:
            ax.plot(veh_hist[:, 0], veh_hist[:, 1], 'k')
            ax.plot(veh_hist[:, 0], veh_hist[:, 1], '.k')
            ax.plot(veh_hist[-1, 0], veh_hist[-1, 1], 'o')

    ax.plot(fut_gt[:, 0], fut_gt[:, 1], 'g', label='fut_gt')
    ax.plot(fut_gt[:, 0], fut_gt[:, 1], '.g')
    ax.plot(fut_gt[-1, 0], fut_gt[-1, 1], 'og')

    ax.plot(fut_pred[0, :, 0], fut_pred[0, :, 1], 'r', label='fut_pred')
    ax.plot(fut_pred[0, :, 0], fut_pred[0, :, 1], '.r')
    ax.plot(fut_pred[0, -1, 0], fut_pred[0, -1, 1], 'or')

    # file_name = save_path.split('/')[-1][3:-4]
    # plt.title(file_name)
    plt.xlabel('X(m)')
    plt.ylabel('Y(m)')
    # plt.legend()
    box = ax.get_position()
    ax.set_position([box.x0, box.y0, box.width * 0.8, box.height])

    # # Put a legend to the right of the current axis
    ax.legend(loc='center left', bbox_to_anchor=(1, 0.5))
    # # plt.show()
    plt.savefig(save_path, facecolor='white', edgecolor='none')
    plt.close()


def make_video(hists_dict, fut_pred_dict, fut_gt_dict, duration, save_path, fps=10):
    """
    生成视频

    Parameters
    ----------
    hists_dict : dict
        历史轨迹的字典，key为帧id，value为历史轨迹（n*30*2）
    fut_pred_dict : dict
        预测的未来轨迹字典，key为帧id，value为预测的未来轨迹（50*2）
    fut_gt_dict : dict
        实际的未来轨迹字典，key为帧id，value为实际的未来轨迹（50*2）
    duration : float/int
        视频时长
    save_path : string 
        保存路径
    fps : int, optional
        每秒帧数, by default 10
    """

    def make_frame(t):
        frm = int(10 * t)
        hists = hists_dict[frm]
        fut_pred = fut_pred_dict[frm]
        fut_gt = fut_gt_dict[frm]
        fig, ax = plt.subplots(dpi=300)
        plt.xlim(-100, 250)
        plt.ylim(-8, 4)
        for i, veh_hist in enumerate(hists):
            if i == 0:
                ax.plot(veh_hist[:, 0], veh_hist[:, 1], 'b', label='target_hist')
                ax.plot(veh_hist[:, 0], veh_hist[:, 1], '.b')
                ax.plot(veh_hist[-1, 0], veh_hist[-1, 1], 'or')
            else:
                ax.plot(veh_hist[:, 0], veh_hist[:, 1], 'k')
                ax.plot(veh_hist[:, 0], veh_hist[:, 1], '.k')
                ax.plot(veh_hist[-1, 0], veh_hist[-1, 1], 'o')

        ax.plot(fut_gt[:, 0], fut_gt[:, 1], 'g', label='fut_gt')
        ax.plot(fut_gt[:, 0], fut_gt[:, 1], '.g')
        ax.plot(fut_gt[-1, 0], fut_gt[-1, 1], 'og')

        ax.plot(fut_pred[0, :, 0], fut_pred[0, :, 1], 'r', label='fut_pred')
        ax.plot(fut_pred[0, :, 0], fut_pred[0, :, 1], '.r')
        ax.plot(fut_pred[0, -1, 0], fut_pred[0, -1, 1], 'or')

        plt.xlabel('X(m)')
        plt.ylabel('Y(m)')
        box = ax.get_position()
        ax.set_position([box.x0, box.y0, box.width * 0.8, box.height])

        # # Put a legend to the right of the current axis
        ax.legend(loc='center left', bbox_to_anchor=(1, 0.5))
        plt.close()
        return mplfig_to_npimage(fig)

    animation = VideoClip(make_frame, duration=duration)
    animation.write_videofile(save_path, fps=fps)


if __name__ == '__main__':
    import pickle
    with open(f"imgs/ld_eval_imgs/ds7_id36/ds7_id36_dict", "rb") as fp:  #Pickling
        ds7_id36_dict = pickle.load(fp)
    hists_dict, fut_pred_dict, fut_gt_dict = {}, {}, {}
    for t in range(100):
        hists = ds7_id36_dict[1140 + t]["rotate_glb_pos"]
        fut_gt = ds7_id36_dict[1140 + t]["rotate_fur_gt"]
        fut_pred = ds7_id36_dict[1140 + t]["rotate_fut_pred"]

        hists_dict[t] = hists
        fut_pred_dict[t] = fut_pred
        fut_gt_dict[t] = fut_gt
        # break

    duration = 10
    save_path = "/home/jiang/trajectory_pred/GNN-RNN-Based-Trajectory-Prediction-ITSC2021/imgs/ld_eval_imgs/ds7_id36/ds7_id36_1140_1240_3.mp4"
    make_video(hists_dict, fut_pred_dict, fut_gt_dict, duration, save_path)
